package com.example.security.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.security.model.Task;
import com.example.security.repository.TaskRepository;

@Service
public class TaskService {
    @Autowired
    private TaskRepository taskRepository;

    public TaskService(TaskRepository taskRepository) {
        this.taskRepository = taskRepository;
    }

    @SuppressWarnings("null")
    public void createTask(Task task) {
        taskRepository.save(task);
    }

    public List<Task> getTasks() {
        return taskRepository.findAll();
    }

    public void updateTask(Task task) {
        @SuppressWarnings("null")
        Task updated = taskRepository.findById(task.getId()).orElseThrow();
        updated.setName(task.getName());
        updated.setDescription(task.getDescription());
        updated.setDone(task.isDone());
        taskRepository.save(updated);
    }

    @SuppressWarnings("null")
    public Task getTaskById(Long id) {
        return taskRepository.findById(id).orElseThrow();
    }

    @SuppressWarnings("null")
    public void deleteTaskById(Long id) {
        taskRepository.deleteById(id);
    }
}
