package com.example.security.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.security.model.Task;

public interface TaskRepository extends JpaRepository<Task, Long> {
}
