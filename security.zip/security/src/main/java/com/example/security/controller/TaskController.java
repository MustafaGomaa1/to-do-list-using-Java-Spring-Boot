package com.example.security.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;

import com.example.security.model.Task;
import com.example.security.service.TaskService;

import jakarta.validation.Valid;

@Controller
public class TaskController {
    @Autowired
    private TaskService taskService;

    public TaskController(TaskService taskService) {
        this.taskService = taskService;
    }

    @GetMapping("/")
    public String getTasks(Model model) {
        model.addAttribute("task", taskService.getTasks());
        return "tasks.html";
    }

    @GetMapping("/task/new")
    public String getCreateTask(Model model) {
        model.addAttribute("task", new Task());
        return "create-task.html";
    }

    @PostMapping("/task/new/create")
    public String postCreateTask(@Valid @ModelAttribute("task") Task task, BindingResult result) {
        try {
            if (result.hasErrors())
                return "redirect:/new?error=true";
            taskService.createTask(task);
            return "redirect:/";
        } catch (Exception e) {
            System.out.println(e);
            return e.toString();
        }
    }

    @GetMapping("/task/edit/{id}")
    public String getUpdateForm(@PathVariable("id") Long id, Model model) throws Exception {
        model.addAttribute("task", taskService.getTaskById(id));
        return "update-task.html";
    }

    @PostMapping("/task/edit/{id}/update")
    public String postUpdateForm(@Valid @ModelAttribute("task") Task task, BindingResult result) {
        if (result.hasErrors())
            return "update-task.html";
        taskService.updateTask(task);
        return "redirect:/";
    }

    @GetMapping("/task/delete/{id}")
    public String deleteTask(@PathVariable("id") Long id) {
        taskService.deleteTaskById(id);
        return "redirect:/";
    }

}
